"""
Email Agent - Yandex Mail → Claude AI tahlil → Telegram
Yangi xatlar kelganda avtomatik tahlil qilib Telegramga yuboradi.
"""

import imaplib
import email
import time
import json
import os
import logging
import requests
from email.header import decode_header
from datetime import datetime
from pathlib import Path

# ─── LOGGING ───────────────────────────────────────────────────────────────────
# .env faylini o'qish (Windows uchun)
env_path = Path(__file__).parent / ".env"
if env_path.exists():
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, value = line.partition("=")
                os.environ.setdefault(key.strip(), value.strip())

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("agent.log", encoding="utf-8"),
        logging.StreamHandler(open(os.devnull, 'w'))  # Windows CP1252 xatosini oldini olish
    ]
)
log = logging.getLogger(__name__)

# ─── SOZLAMALAR ────────────────────────────────────────────────────────────────
YANDEX_EMAIL    = os.environ["YANDEX_EMAIL"]       # sizning@yandex.ru
YANDEX_PASSWORD = os.environ["YANDEX_PASSWORD"]    # ilovalar paroli (app password)
TELEGRAM_TOKEN  = os.environ["TELEGRAM_TOKEN"]     # BotFather'dan olingan token
TELEGRAM_CHAT_ID= os.environ["TELEGRAM_CHAT_ID"]   # sizning Telegram ID'ingiz
GEMINI_KEY      = os.environ["GEMINI_API_KEY"]      # Google Gemini API key (bepul!)
CHECK_INTERVAL  = int(os.environ.get("CHECK_INTERVAL", "60"))  # soniyada tekshirish

SEEN_IDS_FILE = "seen_ids.json"
IMAP_HOST = "imap.yandex.ru"   # Yandex 360 korporativ uchun ham shu
IMAP_PORT = 993

# ─── YORDAMCHI FUNKSIYALAR ─────────────────────────────────────────────────────

def load_seen_ids() -> set:
    """Ilgari ko'rilgan xat ID'larini yuklash."""
    if Path(SEEN_IDS_FILE).exists():
        with open(SEEN_IDS_FILE) as f:
            return set(json.load(f))
    return set()


def save_seen_ids(ids: set):
    """Ko'rilgan xat ID'larini saqlash."""
    with open(SEEN_IDS_FILE, "w") as f:
        json.dump(list(ids), f)


def decode_str(value: str) -> str:
    """Email header'larini to'g'ri dekodlash (utf-8, cp1251 va h.k.)."""
    if not value:
        return ""
    parts = decode_header(value)
    result = []
    for part, enc in parts:
        if isinstance(part, bytes):
            result.append(part.decode(enc or "utf-8", errors="replace"))
        else:
            result.append(part)
    return " ".join(result)


def get_email_body(msg: email.message.Message) -> str:
    """Xat matnini (plain text yoki HTML dan tozalangan) olish."""
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            if content_type == "text/plain":
                charset = part.get_content_charset() or "utf-8"
                body = part.get_payload(decode=True).decode(charset, errors="replace")
                break
            elif content_type == "text/html" and not body:
                charset = part.get_content_charset() or "utf-8"
                raw_html = part.get_payload(decode=True).decode(charset, errors="replace")
                # HTML teglarini olib tashlash (oddiy usul)
                import re
                body = re.sub(r"<[^>]+>", " ", raw_html)
                body = re.sub(r"\s+", " ", body).strip()
    else:
        charset = msg.get_content_charset() or "utf-8"
        body = msg.get_payload(decode=True).decode(charset, errors="replace")
    return body.strip()


# ─── CLAUDE TAHLIL ─────────────────────────────────────────────────────────────

def analyze_email(sender: str, subject: str, body: str) -> str:
    """Gemini yordamida xatni tahlil qilish (bepul!)."""
    prompt = f"""Siz xaridorlarning xatlarini tahlil qiladigan biznes assistantsiz.
Quyidagi xatni o'qib, biznes egasiga qisqa va lo'nda ma'lumot bering.

XATDAN: {sender}
MAVZU: {subject}

XABAR MATNI:
{body[:4000]}

---
Iltimos, quyidagi formatda javob bering:

🎯 MAQSAD: (xaridor nima xohlaydi — 1-2 jumla)
📦 MAHSULOT QIZIQISHI: (qaysi mahsulot/xizmat haqida so'rayapti)
💰 XARID NIYATI: (Yuqori / O'rta / Past — sababi bilan)
❓ ASOSIY SAVOLLAR: (3-5 ta bullet point)
⚡ TAVSIYA: (keyingi qadam — qanday javob berish kerak)"""

    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GEMINI_KEY}"
    payload = {
        "contents": [{"parts": [{"text": prompt}]}]
    }
    resp = requests.post(url, json=payload, timeout=30)
    resp.raise_for_status()
    data = resp.json()
    return data["candidates"][0]["content"]["parts"][0]["text"]


# ─── TELEGRAM ─────────────────────────────────────────────────────────────────

def send_telegram(text: str):
    """Telegram botga xabar yuborish."""
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    # Telegram uchun 4096 belgidan uzun bo'lsa bo'laklash
    max_len = 4000
    chunks = [text[i:i+max_len] for i in range(0, len(text), max_len)]
    for chunk in chunks:
        payload = {
            "chat_id": TELEGRAM_CHAT_ID,
            "text": chunk,
            "parse_mode": "Markdown"
        }
        resp = requests.post(url, json=payload, timeout=10)
        if not resp.ok:
            log.error(f"Telegram xato: {resp.text}")


def format_telegram_message(sender: str, subject: str, analysis: str) -> str:
    now = datetime.now().strftime("%d.%m.%Y %H:%M")
    return (
        f"📧 *YANGI XARIDOR XATI*\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 *Kim:* `{sender}`\n"
        f"📌 *Mavzu:* {subject}\n"
        f"🕐 *Vaqt:* {now}\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"{analysis}"
    )


# ─── IMAP ULANISH VA TEKSHIRISH ────────────────────────────────────────────────

def fetch_new_emails(seen_ids: set) -> list[dict]:
    """Yangi o'qilmagan xatlarni olish."""
    new_emails = []
    try:
        mail = imaplib.IMAP4_SSL(IMAP_HOST, IMAP_PORT)
        mail.login(YANDEX_EMAIL, YANDEX_PASSWORD)
        mail.select("INBOX")

        # O'qilmagan xatlarni qidirish
        _, data = mail.search(None, "UNSEEN")
        ids = data[0].split()

        for uid in ids:
            uid_str = uid.decode()
            if uid_str in seen_ids:
                continue

            _, msg_data = mail.fetch(uid, "(RFC822)")
            raw = msg_data[0][1]
            msg = email.message_from_bytes(raw)

            sender  = decode_str(msg.get("From", ""))
            subject = decode_str(msg.get("Subject", "(mavzusiz)"))
            body    = get_email_body(msg)

            new_emails.append({
                "uid": uid_str,
                "sender": sender,
                "subject": subject,
                "body": body
            })
            log.info(f"Yangi xat topildi: {sender} — {subject}")

        mail.logout()
    except Exception as e:
        log.error(f"IMAP xato: {e}")

    return new_emails


# ─── ASOSIY TSIKL ─────────────────────────────────────────────────────────────

def main():
    log.info("Email Agent ishga tushdi ✅")
    send_telegram("🤖 *Email Agent ishga tushdi!*\nYangi xaridor xatlari avtomatik tahlil qilinadi.")

    seen_ids = load_seen_ids()

    while True:
        try:
            log.info("Pochta tekshirilmoqda...")
            new_emails = fetch_new_emails(seen_ids)

            for em in new_emails:
                log.info(f"Tahlil qilinmoqda: {em['sender']}")
                analysis = analyze_email(em["sender"], em["subject"], em["body"])
                message  = format_telegram_message(em["sender"], em["subject"], analysis)
                send_telegram(message)

                seen_ids.add(em["uid"])
                save_seen_ids(seen_ids)
                log.info(f"Yuborildi: {em['sender']}")
                time.sleep(2)  # API cheklovi uchun

        except Exception as e:
            log.error(f"Asosiy tsikl xato: {e}")
            send_telegram(f"⚠️ Agent xatolik: `{e}`")

        time.sleep(CHECK_INTERVAL)


if __name__ == "__main__":
    main()
